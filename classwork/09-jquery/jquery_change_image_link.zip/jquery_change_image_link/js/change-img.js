$(document).ready(function(){
    //hover over .animal-img change image to kitten on hover in
    //change to puppy on hover out
	
});

function changeToKitten()
{	

}

function changeToPuppy()
{	

}