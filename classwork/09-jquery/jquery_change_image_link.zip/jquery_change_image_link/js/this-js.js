$(document).ready(function(){
	$(".fun-link").click(showLinkText);
});

function showLinkText()
{
    // get text from element and alert it

}