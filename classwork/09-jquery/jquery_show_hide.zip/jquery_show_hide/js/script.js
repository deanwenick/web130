$(document).ready(function(){
	$("#push-me").click(doStuff);
	$("#show-btn").click(showFlowers);
	$("#hide-btn").click(hideFlowers);
});

function doStuff()
{
    //put "hello in #place-text"
}

function showFlowers()
{
    //show #flowers
}

function hideFlowers()
{
    //hide #flowers
}






